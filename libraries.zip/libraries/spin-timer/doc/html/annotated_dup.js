var annotated_dup =
[
    [ "DefaultUptimeInfoAdapter", "class_default_uptime_info_adapter.html", "class_default_uptime_info_adapter" ],
    [ "Mock_SpinTimerAction", "class_mock___spin_timer_action.html", "class_mock___spin_timer_action" ],
    [ "Mock_UptimeInfo", "class_mock___uptime_info.html", "class_mock___uptime_info" ],
    [ "MySpinTimerAction", "class_my_spin_timer_action.html", "class_my_spin_timer_action" ],
    [ "RaspbianUptimeAdapter", "class_raspbian_uptime_adapter.html", "class_raspbian_uptime_adapter" ],
    [ "SpinTimer", "class_spin_timer.html", "class_spin_timer" ],
    [ "SpinTimerAction", "class_spin_timer_action.html", "class_spin_timer_action" ],
    [ "SpinTimerContext", "class_spin_timer_context.html", "class_spin_timer_context" ],
    [ "SpinTimerRecurring", "class_spin_timer_recurring.html", "class_spin_timer_recurring" ],
    [ "SpinTimerRecurringTestParam", "struct_spin_timer_recurring_test_param.html", "struct_spin_timer_recurring_test_param" ],
    [ "SpinTimerSingleShot", "class_spin_timer_single_shot.html", "class_spin_timer_single_shot" ],
    [ "STM32UptimeInfoAdapter", "class_s_t_m32_uptime_info_adapter.html", "class_s_t_m32_uptime_info_adapter" ],
    [ "UptimeInfo", "class_uptime_info.html", "class_uptime_info" ],
    [ "UptimeInfoAdapter", "class_uptime_info_adapter.html", "class_uptime_info_adapter" ]
];