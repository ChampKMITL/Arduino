var class_uptime_info =
[
    [ "UptimeInfo", "class_uptime_info.html#a959cd9f3f342d22ebc64d51308b8d285", null ],
    [ "~UptimeInfo", "class_uptime_info.html#a9d9348a4222919856948865288d8df78", null ],
    [ "setAdapter", "class_uptime_info.html#a7155badb58740ef7dca8d40c7aeedd9c", null ]
];