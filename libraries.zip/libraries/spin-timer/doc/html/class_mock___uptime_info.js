var class_mock___uptime_info =
[
    [ "Mock_UptimeInfo", "class_mock___uptime_info.html#a469a5fd74e73641cb87c8747cb6eb429", null ],
    [ "incrementTMillis", "class_mock___uptime_info.html#a6e01b78a1f3ab4fa5502998cf06863c5", null ],
    [ "setTMillis", "class_mock___uptime_info.html#a8ee2baa5f908b1b6e75cfd94890dd594", null ],
    [ "tMillis", "class_mock___uptime_info.html#af756fc4b5d781359177024986d42d652", null ]
];