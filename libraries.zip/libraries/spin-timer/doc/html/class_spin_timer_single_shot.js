var class_spin_timer_single_shot =
[
    [ "SpinTimerSingleShot", "class_spin_timer_single_shot.html#a337222ed904da8e46d585046cdbfa152", null ],
    [ "timer", "class_spin_timer_single_shot.html#a47f30d30e6eadb58d528fb3cb278def0", null ]
];