var class_my_spin_timer_action =
[
    [ "MySpinTimerAction", "class_my_spin_timer_action.html#ab8ab96f1645a9c968f3df2582312fb91", null ],
    [ "timeExpired", "class_my_spin_timer_action.html#a45821006c763829257f09efd190d243d", null ]
];