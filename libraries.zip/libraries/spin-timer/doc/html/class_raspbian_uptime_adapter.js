var class_raspbian_uptime_adapter =
[
    [ "RaspbianUptimeAdapter", "class_raspbian_uptime_adapter.html#a8c487fdccaa4a25ae2a3cd5d05c7b0d8", null ],
    [ "~RaspbianUptimeAdapter", "class_raspbian_uptime_adapter.html#a3c50a29cf27c2c1298b7a04262128b30", null ],
    [ "tMillis", "class_raspbian_uptime_adapter.html#a93292043f9bcba83fdb8b21cc538d64b", null ]
];