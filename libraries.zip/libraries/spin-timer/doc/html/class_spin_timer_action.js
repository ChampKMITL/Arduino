var class_spin_timer_action =
[
    [ "SpinTimerAction", "class_spin_timer_action.html#a0b437da1effbd4db70c6ec38e03a2b5d", null ],
    [ "~SpinTimerAction", "class_spin_timer_action.html#aad137fa7001d31166f718577a4af02dd", null ],
    [ "timeExpired", "class_spin_timer_action.html#a45bccad7275feeabaaacf867437787b7", null ]
];