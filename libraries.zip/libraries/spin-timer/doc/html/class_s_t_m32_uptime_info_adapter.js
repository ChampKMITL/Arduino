var class_s_t_m32_uptime_info_adapter =
[
    [ "tMillis", "class_s_t_m32_uptime_info_adapter.html#aa7083a7f31328e64283a34a988f52c04", null ]
];