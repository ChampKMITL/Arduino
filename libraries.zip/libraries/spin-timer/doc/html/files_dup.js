var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "Examples", "dir_03680f297d755c096b0a1ead13ee12b7.html", "dir_03680f297d755c096b0a1ead13ee12b7" ],
    [ "tests", "dir_59425e443f801f1f2fd8bbe4959a3ccf.html", "dir_59425e443f801f1f2fd8bbe4959a3ccf" ],
    [ "SpinTimer.cpp", "_spin_timer_8cpp.html", "_spin_timer_8cpp" ],
    [ "SpinTimer.h", "_spin_timer_8h.html", "_spin_timer_8h" ],
    [ "SpinTimerContext.cpp", "_spin_timer_context_8cpp.html", null ],
    [ "SpinTimerContext.h", "_spin_timer_context_8h.html", [
      [ "SpinTimerContext", "class_spin_timer_context.html", "class_spin_timer_context" ]
    ] ],
    [ "UptimeInfo.cpp", "_uptime_info_8cpp.html", [
      [ "DefaultUptimeInfoAdapter", "class_default_uptime_info_adapter.html", "class_default_uptime_info_adapter" ]
    ] ],
    [ "UptimeInfo.h", "_uptime_info_8h.html", [
      [ "UptimeInfoAdapter", "class_uptime_info_adapter.html", "class_uptime_info_adapter" ],
      [ "UptimeInfo", "class_uptime_info.html", "class_uptime_info" ]
    ] ]
];