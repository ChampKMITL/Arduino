var searchData=
[
  ['include_142',['include',['../tests_2_c_make_lists_8txt.html#add1f16e08992a496ae917619a8b887ed',1,'CMakeLists.txt']]],
  ['incrementtmillis_143',['incrementTMillis',['../class_mock___uptime_info.html#a6e01b78a1f3ab4fa5502998cf06863c5',1,'Mock_UptimeInfo']]],
  ['instance_144',['instance',['../class_spin_timer_context.html#aa00434d24de7d35ef45f6789f19b3ab8',1,'SpinTimerContext::instance()'],['../class_uptime_info.html#a6978a042bec2689d1e80d0de87237602',1,'UptimeInfo::Instance()']]],
  ['instantiate_5ftest_5fcase_5fp_145',['INSTANTIATE_TEST_CASE_P',['../_test___spin_timer_8cpp.html#a995a1fe580eda2aaefbcf29e7a77f365',1,'INSTANTIATE_TEST_CASE_P(SpinTimer, SpinTimerSingleShot, ::testing::Values(std::make_tuple(10, 0), std::make_tuple(10, ULONG_MAX), std::make_tuple(10, ULONG_MAX - 1), std::make_tuple(10, ULONG_MAX - 10), std::make_tuple(10, ULONG_MAX - 10+1), std::make_tuple(0, 0), std::make_tuple(0, ULONG_MAX), std::make_tuple(0, ULONG_MAX - 1), std::make_tuple(0, ULONG_MAX - 0), std::make_tuple(0, ULONG_MAX - 0+1))):&#160;Test_SpinTimer.cpp'],['../_test___spin_timer_8cpp.html#a8a6de03b9044240ef6260438bd39d63e',1,'INSTANTIATE_TEST_CASE_P(SpinTimer, SpinTimerRecurring, ::testing::Values(SpinTimerRecurringTestParam(10, 0, 1), SpinTimerRecurringTestParam(10, 0, 10), SpinTimerRecurringTestParam(10, 0, 100), SpinTimerRecurringTestParam(10, ULONG_MAX, 500), SpinTimerRecurringTestParam(10, ULONG_MAX-1, 500))):&#160;Test_SpinTimer.cpp']]],
  ['isexpired_146',['isExpired',['../class_spin_timer.html#a98522222b5fdaf2609164d55dfcf1001',1,'SpinTimer']]],
  ['isrunning_147',['isRunning',['../class_spin_timer.html#a74e21666ec8e2cfd880117a5b39c74f9',1,'SpinTimer']]]
];
